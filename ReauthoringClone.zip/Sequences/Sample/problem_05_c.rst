Base 16
-------

The base 16 representation of a binary number is obtained by considering bits in
groups of **four** starting from

A) The most significant bit
#) The least significant bit
#) It doesn't matter
#) It depends on the value of the number

.. iguide:: Solution

   1

.. Number from 0 to num-answers - 1

