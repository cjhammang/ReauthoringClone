Exercises in the Sequence
=========================

.. toctree::
   :numbered:
   :glob:

   *_c

