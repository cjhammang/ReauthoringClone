Will it fit?
------------

A computer system needs to perform numeric operations over **integers** 
encoded in 2's complement and they would like to process positive integers up 
to 2,147,483,647. How many bits would you recommend they use? Remember that with 
n bits the range of numbers that can be represented is :math:`[-(2^{n-1}), 
2^{n-1} - 1]`

A) 30 bits
#) 31 bits
#) 32 bits
#) None of the above

.. iguide:: Solution

   2

.. iguide:: Solution

   2

.. Number from 0 to num-answers - 1

