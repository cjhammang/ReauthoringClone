Encoding information
--------------------

You are given the sequence of bits `01001101`. It encodes...

A) The letter 'M' in ASCII
#) the number 77 in base 10
#) the real number 77.0
#) Impossible to tell!  

.. iguide:: Solution

   3 We need the context

