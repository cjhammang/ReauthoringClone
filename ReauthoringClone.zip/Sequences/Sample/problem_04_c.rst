Base 8
------

The base 8 representation of a binary number is obtained by considering bits in
groups of **three** starting from

A) The least significant bit
#) The most significant bit
#) It doesn't matter
#) It depends on the value of the number

.. iguide:: Solution

   0

.. Number from 0 to num-answers - 1

