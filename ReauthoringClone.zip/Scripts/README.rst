:orphan:

=============================
 Scripts for Auxiliary Tasks
=============================

This folder contains scripts that are needed to perform auxiliary tasks
connected with the workflow to publish the material generated in this
site. They typically require a substantial amount of configuration in a remote
server before they are used.
